#!/bin/bash

# Define ANSI color codes
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

#cd /home/hevan/LORAM

export BASE_DIR=`pwd`
export BUILD_DIR="${BASE_DIR}/build"
export CONFIG_DIR="${BASE_DIR}/icm4-configs"
export IMAGE_DIR="${BUILD_DIR}/tmp/deploy/images/sama5d2-xplained-sd"

if [ ! -d "$BASE_DIR/source" ];
then

	echo -e "${CYAN}Install build system dependencies, will need sudo access for this step${NC}"
	sudo apt install gawk wget git diffstat unzip texinfo gcc build-essential chrpath socat cpio python3 python3-pip python3-pexpect xz-utils debianutils iputils-ping python3-git python3-jinja2 libegl1-mesa libsdl1.2-dev python3-subunit mesa-common-dev zstd liblz4-tool file locales libacl1 device-tree-compiler -y
	
	mkdir source
fi

if [ ! -d "$BASE_DIR/icm4-configs" ];
then
	if [ -f "icm4-configs.zip" ];
	then
		unzip icm4-configs.zip -d .
		#rm icm4-configs.zip
	else
		echo -e "${RED} icm4-configs.zip is not found. ${NC}"
		exit 1
	fi
fi

if [ ! -d "$BASE_DIR/source/meta-icm4" ];
then
	if [ ! -d "$BASE_DIR/icm4-configs" ];
	then
		if [ -f "icm4-configs.zip" ];
		then
			unzip icm4-configs.zip -d .
			#rm icm4-configs.zip
		else
			echo -e "${RED} icm4-configs.zip is not found. ${NC}"
			exit 1
		fi
	fi
	if [ -f "${CONFIG_DIR}/meta-icm4.zip" ];
	then
		unzip ${CONFIG_DIR}/meta-icm4.zip -d source
		#rm ${CONFIG_DIR}/meta-icm4.zip
	else
		echo -e "${RED} ${CONFIG_DIR}/meta-icm4.zip is not found. ${NC}"
		exit 1
	fi
fi

cd source

if [ ! -d "$BASE_DIR/source/poky" ];
then
	# Clone yocto/poky git repository with the proper branch ready
	git clone https://git.yoctoproject.org/poky && cd poky && git checkout -b kirkstone yocto-4.0.13 && cd -
	
	if [ -f "${CONFIG_DIR}/yocto/.templateconf" ];
	then
		# Copy .templateconf file from icm4-config
		cp "${CONFIG_DIR}/yocto/.templateconf" "${BASE_DIR}/source/poky/"
	else
		echo -e "${RED} ${CONFIG_DIR}/yocto/.templateconf is not found. ${NC}"
		exit 1
	fi
fi

if [ ! -d "$BASE_DIR/source/meta-openembedded" ];
then
	# Clone meta-openembedded git repository with the proper branch ready
	git clone git://git.openembedded.org/meta-openembedded && cd meta-openembedded && git checkout -b kirkstone 79a6f6 && cd -
fi

if [ ! -d "$BASE_DIR/source/meta-atmel" ];
then
	# Clone meta-atmel layer with the proper branch ready
	git clone https://github.com/linux4sam/meta-atmel.git -b kirkstone
fi

if [ ! -d "$BASE_DIR/source/meta-arm" ];
then
	# Clone meta-arm layer with the proper branch ready
	git clone https://git.yoctoproject.org/meta-arm && cd meta-arm && git checkout -b kirkstone yocto-4.0.1 && cd -
fi

#fi #temp

if [ ! -d "$BASE_DIR/build/conf" ];
then
	# Make build and config dirs
	mkdir --parents "${BASE_DIR}/build/conf"
fi

# Enter the poky directory to configure the build system and start the build process
cd poky


# Initial build

# Initialize build directory
source oe-init-build-env ../../build > /dev/null 2>&1
 
# Add locale settings to ~/.bashrc if not already present
if ! grep -q "export LC_ALL=\"en_US.UTF-8\"" ~/.bashrc; then
    echo 'export LC_ALL="en_US.UTF-8"' >> ~/.bashrc
fi
 
if ! grep -q "export LC_CTYPE=\"en_US.UTF-8\"" ~/.bashrc; then
    echo 'export LC_CTYPE="en_US.UTF-8"' >> ~/.bashrc
fi
 
# Apply changes to the current session
export LC_ALL="en_US.UTF-8"
export LC_CTYPE="en_US.UTF-8"
 
echo "Locale settings have been configured."

if [ -f "${IMAGE_DIR}/firmware.txz" ]; then
	# remove old tarbal
	rm ${IMAGE_DIR}/firmware.txz
fi
# remoce old Additional build artifacts
#rm ${IMAGE_DIR}/BOOT.BIN
if [ -f "${IMAGE_DIR}/BOOT_1.BIN" ]; then
	rm ${IMAGE_DIR}/BOOT_1.BIN
fi
if [ -f "${IMAGE_DIR}/BOOT_2.BIN" ]; then
	rm ${IMAGE_DIR}/BOOT_2.BIN
fi
if [ -f "${IMAGE_DIR}/firmware.itb" ]; then
	rm ${IMAGE_DIR}/firmware.itb
fi
if [ -f "${IMAGE_DIR}/flash_1.bin" ]; then
	rm ${IMAGE_DIR}/flash_1.bin
fi
if [ -f "${IMAGE_DIR}/flash_2.bin" ]; then
	rm ${IMAGE_DIR}/flash_2.bin
fi
if [ -f "${IMAGE_DIR}/icm4-image-sama5d2-xplained-sd.tar.gz" ]; then
	rm ${IMAGE_DIR}/icm4-image-sama5d2-xplained-sd.tar.gz
fi
if [ -d "${IMAGE_DIR}/img" ]; then
	rm -r ${IMAGE_DIR}/img
fi
cd ${BUILD_DIR}
if [ -d "${BASE_DIR}/source/meta-icm4/recipes-bsp/at91bootstrap" ]; then
	rm -rf ${BASE_DIR}/source/meta-icm4/recipes-bsp/at91bootstrap
fi

if [ -f "${BASE_DIR}/source/meta-icm4/recipes-bsp/at91bootstrap_1.zip" ];
then
	unzip ${BASE_DIR}/source/meta-icm4/recipes-bsp/at91bootstrap_1.zip -d ${BASE_DIR}/source/meta-icm4/recipes-bsp/at91bootstrap
else
	echo -e "${RED} ${BASE_DIR}/source/meta-icm4/recipes-bsp/at91bootstrap_1.zip is not found. ${NC}"
	exit 1
fi

bitbake  icm4-image

if [ -f "${IMAGE_DIR}/BOOT.BIN" ];
then
	# Make a copy of the image file for Flash_1, for later FIT image creation
	cp "${IMAGE_DIR}/BOOT.BIN" "${IMAGE_DIR}/BOOT_1.BIN"
else
	echo -e "${RED} ${IMAGE_DIR}/BOOT.BIN is not found. ${NC}"
	exit 1
fi

rm -rf ${BASE_DIR}/source/meta-icm4/recipes-bsp/at91bootstrap


if [ -f "${BASE_DIR}/source/meta-icm4/recipes-bsp/at91bootstrap_2.zip" ];
then
	unzip ${BASE_DIR}/source/meta-icm4/recipes-bsp/at91bootstrap_2.zip -d ${BASE_DIR}/source/meta-icm4/recipes-bsp/at91bootstrap
else
	echo -e "${RED} ${BASE_DIR}/source/meta-icm4/recipes-bsp/at91bootstrap_2.zip is not found. ${NC}"
	exit 1
fi

bitbake icm4-image

if [ -f "${IMAGE_DIR}/BOOT.BIN" ];
then
	# Make a copy of the image file for Flash_2, for later FIT image creation
	cp "${IMAGE_DIR}/BOOT.BIN" "${IMAGE_DIR}/BOOT_2.BIN"
else
	echo -e "${RED} ${IMAGE_DIR}/BOOT.BIN is not found. ${NC}"
	exit 1
fi

########################################
# Make flash_# images

# Change into the images directory
cd "${IMAGE_DIR}"

### Make flash_1 image file ###

# Create an 8Kib file filled with 0xFF
head -c 8192 /dev/zero | tr "\000" "\377" > flash_1.bin

# Add BOOT_1 to the beginning of the file, leaving the trailing 0xFF filler untouched
dd if=BOOT_1.BIN of=flash_1.bin conv=notrunc

# Add u-boot to the end of the file
cat u-boot.bin >> flash_1.bin

### Make flash_2 image file ###

# Create an 8Kib file filled with 0xFF
head -c 8192 /dev/zero | tr "\000" "\377" > flash_2.bin

# Add BOOT_2 to the beginning of the file, leaving the trailing 0xFF filler untouched
dd if=BOOT_2.BIN of=flash_2.bin conv=notrunc

# Add u-boot to the end of the file
cat u-boot.bin >> flash_2.bin

########################################
# FIT Image Creation

# Change into the images directory
cd "${IMAGE_DIR}"

# Copy FIT image definition file into image directory and update version info
export LTI_IMAGE_VERSION='ICM4-2024.04.26'
sed "s/%%LTI_IMAGE_VERSION%%/${LTI_IMAGE_VERSION}/g" "${CONFIG_DIR}/fit-image/icm4.its" > icm4.its

# Make FIT image
"${BUILD_DIR}/tmp/sysroots-components/x86_64/u-boot-tools-native/usr/bin/mkimage" -f icm4.its firmware.itb

########################################
# Firmware installation tarball image creation

# Change into the images directory
cd "${IMAGE_DIR}"

# Create a working directory
mkdir --parents img

# Copy manifest file and io binaries from icm4-config
sed "s/%%LTI_IMAGE_VERSION%%/${LTI_IMAGE_VERSION}/g" "${CONFIG_DIR}/fw-image/manifest" > ./img/manifest
cp "${CONFIG_DIR}/fw-image/"*.bin ./img/

# Copy in the Flash_# images
cp flash_[12].bin ./img/

# Copy in the FIT image
cp firmware.itb ./img/

# Hash all the image files
md5sum img/firmware.itb img/flash_[12].bin
########################################

# Function to compute MD5 hash for a given file
compute_md5() {
    local filepath="$1"
    local md5_hash=$(md5sum "$filepath" | awk '{print $1}')
    echo "$md5_hash"
}
 
# Update hashes in the manifest file
update_manifest_hashes() {
    local manifest_file="$1"
 
    # Compute MD5 hashes for the specified files
    local firmware_hash=$(compute_md5 "img/firmware.itb")
    local flash1_hash=$(compute_md5 "img/flash_1.bin")
    local flash2_hash=$(compute_md5 "img/flash_2.bin")
 
    # Replace "xxx" with computed hashes in the manifest file
    sed -i'' "s/\"Linux\": {\"Name\": \"firmware.itb\", \"Hash\": \"xxx\"}/\"Linux\": {\"Name\": \"firmware.itb\", \"Hash\": \"$firmware_hash\"}/" "$manifest_file"
    sed -i'' "s/\"Flash_1\": {\"Name\": \"flash_1.bin\", \"Hash\": \"xxx\"}/\"Flash_1\": {\"Name\": \"flash_1.bin\", \"Hash\": \"$flash1_hash\"}/" "$manifest_file"
    sed -i'' "s/\"Flash_2\": {\"Name\": \"flash_2.bin\", \"Hash\": \"xxx\"}/\"Flash_2\": {\"Name\": \"flash_2.bin\", \"Hash\": \"$flash2_hash\"}/" "$manifest_file"
}

# Define manifest file
manifest_file="${IMAGE_DIR}/img/manifest"
 
# Update hashes in the manifest file
update_manifest_hashes "$manifest_file"
 
echo "Hashes updated in the manifest file."

# Create the firmware update tarball
tar --create --verbose --xz --file firmware.txz --directory img/ .

echo "Firmware Tarball Generated."

